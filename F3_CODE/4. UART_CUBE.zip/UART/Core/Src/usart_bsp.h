#ifndef __USART_BSP_H_
#define	__USART_BSP_H_
#include "stm32f303xc.h"
#include "stm32f3xx.h"
#include <stdio.h>

extern UART_HandleTypeDef huart;
void USART_Config(void);


#endif /* __USART_LED_H_ */
