var struct_n_v_i_c___type =
[
    [ "IABR", "struct_n_v_i_c___type.html#a33e917b381e08dabe4aa5eb2881a7c11", null ],
    [ "ICER", "struct_n_v_i_c___type.html#a1965a2e68b61d2e2009621f6949211a5", null ],
    [ "ICPR", "struct_n_v_i_c___type.html#a46241be64208436d35c9a4f8552575c5", null ],
    [ "IP", "struct_n_v_i_c___type.html#a6524789fedb94623822c3e0a47f3d06c", null ],
    [ "ISER", "struct_n_v_i_c___type.html#af90c80b7c2b48e248780b3781e0df80f", null ],
    [ "ISPR", "struct_n_v_i_c___type.html#acf8e38fc2e97316242ddeb7ea959ab90", null ],
    [ "RESERVED0", "struct_n_v_i_c___type.html#a2de17698945ea49abd58a2d45bdc9c80", null ],
    [ "RESERVED2", "struct_n_v_i_c___type.html#a0953af43af8ec7fd5869a1d826ce5b72", null ],
    [ "RESERVED3", "struct_n_v_i_c___type.html#a9dd330835dbf21471e7b5be8692d77ab", null ],
    [ "RESERVED4", "struct_n_v_i_c___type.html#a5c0e5d507ac3c1bd5cdaaf9bbd177790", null ],
    [ "RESERVED5", "struct_n_v_i_c___type.html#a4f753b4f824270175af045ac99bc12e8", null ],
    [ "RSERVED1", "struct_n_v_i_c___type.html#a6d1daf7ab6f2ba83f57ff67ae6f571fe", null ],
    [ "STIR", "struct_n_v_i_c___type.html#a0b0d7f3131da89c659a2580249432749", null ]
];